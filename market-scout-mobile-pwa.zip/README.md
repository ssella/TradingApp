# Market Scout

Mobile-first installable stock/options research PWA prototype.

## Run locally
```bash
npm install
npm run dev
```

## Deploy to Vercel
Import this repository into Vercel. Framework preset: Vite. Build command: `npm run build`; output: `dist`.

## Current mode
The included market and options data is deterministic demo data. It does not place live trades. Add a server-side market-data provider later; never expose brokerage/API secret keys in browser code.

## Disclaimer
For research/education only. Options involve substantial risk. Research scores and signals are not guarantees or personalized investment advice.
